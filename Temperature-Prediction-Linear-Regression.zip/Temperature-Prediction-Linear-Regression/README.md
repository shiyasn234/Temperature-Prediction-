# Temperature Prediction Using Linear Regression

## 1. Project Overview

This project applies **Multiple Linear Regression** to predict the maximum temperature (`tmax`) in Chennai using historical weather measurements.

The project was prepared to satisfy the Predictive Modeling Project assignment requirements:

- Select a real-world continuous prediction problem.
- Use a publicly available dataset.
- Perform data cleaning and preprocessing.
- Train a Linear Regression model using scikit-learn.
- Evaluate the model using R² score and RMSE.
- Produce meaningful visualizations.
- Organize the work in a GitHub-ready repository.

## 2. Research Problem

**Can historical weather variables be used to predict Chennai's maximum temperature?**

### Objective

To build a Linear Regression model that predicts maximum temperature (`tmax`) from:

- `tavg` — average temperature
- `tmin` — minimum temperature
- `prcp` — precipitation

## 3. Dataset

The project uses the Chennai file from the Kaggle dataset:

**Historical Weather Data for Indian Cities**

Dataset source: https://www.kaggle.com/datasets/hiteshsoneji/historical-weather-data-for-indian-cities

The uploaded source notebook loads:

`Chennai_1990_2022_Madras.csv`

The dataset columns used in the source notebook are:

| Column | Meaning |
|---|---|
| `time` | Date |
| `tavg` | Average temperature |
| `tmin` | Minimum temperature |
| `tmax` | Maximum temperature — target |
| `prcp` | Precipitation |

The uploaded notebook reports 11,894 observations after missing-value treatment.

## 4. Methodology

```text
Dataset
   ↓
Data Cleaning
   ↓
Missing Value Treatment
   ↓
Feature Selection
   ↓
80% Training / 20% Testing
   ↓
Multiple Linear Regression
   ↓
Prediction
   ↓
MAE / MSE / RMSE / R²
   ↓
Visualization
   ↓
Conclusion
```

### Data preprocessing

Missing values are filled using the mode of the corresponding column, matching the approach used in the uploaded notebook.

The date column (`time`) is excluded from the numerical regression features.

### Model

`sklearn.linear_model.LinearRegression`

### Train/Test split

80% training data and 20% testing data.

The supplied project notebook uses:

```python
train_test_split(..., test_size=0.20, random_state=42)
```

This makes the final evaluation reproducible.

## 5. Evaluation Metrics

### Mean Absolute Error (MAE)

Measures the average absolute difference between actual and predicted temperature.

### Mean Squared Error (MSE)

Measures the average squared prediction error.

### Root Mean Squared Error (RMSE)

RMSE is the square root of MSE and is expressed in the same unit as temperature (°C).

### R² Score

Shows how much of the variation in the target variable is explained by the model. A value closer to 1 indicates a better fit.

## 6. Results from the Uploaded Source Notebook

The uploaded notebook's original Linear Regression run reported:

- **MSE:** 2.488092
- **RMSE:** 1.5774 °C

The original notebook did not use a fixed random seed and did not report R². Therefore, the exact R² and the final reproducible metrics are intentionally calculated by the included notebook after the full CSV is supplied.

## 7. Visualizations

The repository includes:

- `actual_vs_predicted_sample.png` — sample of 10 actual and predicted values stored in the uploaded notebook.
- `actual_vs_predicted_scatter.png` — scatter comparison for the same sample.
- The main notebook generates full test-set visualizations after the dataset is loaded.

## 8. How to Run

### Option A — Kaggle

1. Open the notebook in Kaggle.
2. Add the **Historical Weather Data for Indian Cities** dataset.
3. Run all cells.

### Option B — Local Python/Jupyter

1. Download `Chennai_1990_2022_Madras.csv` from the dataset source.
2. Put it in the project folder.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Open:

`Temperature_Prediction_Linear_Regression.ipynb`

5. Run all cells.

## 9. Requirements

- Python 3.x
- pandas
- numpy
- matplotlib
- scikit-learn
- Jupyter Notebook

## 10. Conclusion

The project demonstrates that historical weather measurements can be used as predictors in a supervised regression model for maximum temperature. Linear Regression provides a simple and interpretable baseline model. The model's effectiveness should be judged from the R² and RMSE values produced by the reproducible notebook when run on the complete Chennai CSV.

## 11. Repository Structure

```text
Temperature-Prediction-Linear-Regression/
│
├── README.md
├── Temperature_Prediction_Linear_Regression.ipynb
├── requirements.txt
│
└── visualizations/
    ├── actual_vs_predicted_sample.png
    └── actual_vs_predicted_scatter.png
```
